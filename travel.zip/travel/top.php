	 <div class="header-top">
		 <!--container-->
		  <div class="container">
			 <div class="top-nav">
						<div class="logo">
						<a href="#"><img src="images/" id="section-1" class="img-responsive" alt=""/></a>
						</div>
						<div class="menu">
						<ul id="nav">
							 <li><a href="index.php#section-1"  onclick="javascript:window.open('index.php#section-1','_self')">                            Home</a></li>
							 <li><a href="index.php#section-2"  onclick="javascript:window.open('index.php#section-2','_self')">                           About</a></li>
							 <li><a href="index.php#section-3"  onclick="javascript:window.open('index.php#section-3','_self')">                             Gallery</a></li>
                                 
							 <li><a href="index.php#section-5"   onclick="javascript:window.open('index.php#section-5','_self')">                              Contact</a></li>
							 <li><a href="category.php" onclick="javascript:window.open('category.php','_self')">Category</a></li> 
							 
							 <li><a href="admin/loginform.php"  onclick="javascript:window.open('index.php#section-1','_self')">                            Admin Login</a></li>
							 <div class="clearfix"></div>
						 </ul>
						 </div>
			 </div>
			  <div class="clearfix"> </div>
			

		 </div>
		 <!--/container-->
	 </div>